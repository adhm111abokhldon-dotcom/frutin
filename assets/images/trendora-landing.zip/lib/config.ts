// Central place for the details Adhm will fill in.
// Replace every placeholder below before going live.

export const siteConfig = {
  // Full international format, digits only, no "+" and no spaces.
  // Example: UAE number 050 123 4567 -> "971501234567"
  whatsappNumber: "971500000000",
  brandName: "[Brand Name]",
  instagram: "https://instagram.com/[handle]",
};
