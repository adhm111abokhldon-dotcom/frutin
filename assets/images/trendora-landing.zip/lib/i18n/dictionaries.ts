export type Lang = "ar" | "en";

export const dictionaries = {
  ar: {
    nav: {
      story: "الحكاية",
      notes: "التفاصيل",
      gallery: "المعرض",
      reviews: "الآراء",
      cta: "اطلب الآن",
    },
    hero: {
      eyebrow: "[اسم العلامة]",
      // TODO: Adhm — replace with real product name
      headline: "[اسم المنتج]",
      subheadline:
        "[جملة وصفية قصيرة عن المنتج — إحساسه، مكوناته الأساسية، أو الفكرة وراءه]",
      priceLabel: "يبدأ من",
      price: "[السعر] د.إ",
      ctaPrimary: "اطلب عبر واتساب",
      ctaSecondary: "اكتشف التفاصيل",
      scrollHint: "مرر للأسفل",
    },
    story: {
      eyebrow: "الحكاية",
      title: "[عنوان قصة المنتج]",
      body:
        "[هون بتحكي قصة المنتج — من وين جاية الفكرة، شو بيميزه، وليش الزبون لازم يهتم فيه. فقرة أو فقرتين قصار وكفاية]",
      quote: "[اقتباس قصير مؤثر عن المنتج أو تجربة استخدامه]",
    },
    features: {
      eyebrow: "التفاصيل",
      title: "[عنوان قسم المزايا]",
      items: [
        {
          title: "[ميزة ١]",
          body: "[وصف قصير للميزة الأولى وشو بتضيفه للزبون]",
        },
        {
          title: "[ميزة ٢]",
          body: "[وصف قصير للميزة الثانية]",
        },
        {
          title: "[ميزة ٣]",
          body: "[وصف قصير للميزة الثالثة]",
        },
      ],
    },
    gallery: {
      eyebrow: "المعرض",
      title: "[عنوان قسم الصور]",
      captions: ["[وصف الصورة ١]", "[وصف الصورة ٢]", "[وصف الصورة ٣]", "[وصف الصورة ٤]"],
    },
    testimonials: {
      eyebrow: "آراء الزبائن",
      title: "[عنوان قسم التقييمات]",
      items: [
        { name: "[اسم الزبون ١]", text: "[رأي الزبون الأول بالمنتج]" },
        { name: "[اسم الزبون ٢]", text: "[رأي الزبون الثاني بالمنتج]" },
        { name: "[اسم الزبون ٣]", text: "[رأي الزبون الثالث بالمنتج]" },
      ],
    },
    cta: {
      title: "[دعوة أخيرة للطلب]",
      body: "[جملة قصيرة تحفّز الزبون يطلب هلق عبر واتساب]",
      button: "اطلب عبر واتساب",
    },
    footer: {
      rights: "جميع الحقوق محفوظة",
      brand: "[اسم العلامة]",
    },
    whatsapp: {
      label: "اطلب عبر واتساب",
      message: "مرحبا، حابب اطلب [اسم المنتج]",
    },
    langSwitch: "EN",
  },
  en: {
    nav: {
      story: "Story",
      notes: "Details",
      gallery: "Gallery",
      reviews: "Reviews",
      cta: "Order now",
    },
    hero: {
      eyebrow: "[Brand Name]",
      headline: "[Product Name]",
      subheadline:
        "[Short descriptive line about the product — the feeling, the key ingredients, or the idea behind it]",
      priceLabel: "Starting at",
      price: "AED [price]",
      ctaPrimary: "Order on WhatsApp",
      ctaSecondary: "See the details",
      scrollHint: "Scroll",
    },
    story: {
      eyebrow: "The story",
      title: "[Product story title]",
      body:
        "[This is where the product story goes — where the idea came from, what makes it different, and why the customer should care. One or two short paragraphs is enough]",
      quote: "[A short, striking quote about the product or the experience of using it]",
    },
    features: {
      eyebrow: "Details",
      title: "[Features section title]",
      items: [
        { title: "[Feature 1]", body: "[Short description of the first feature]" },
        { title: "[Feature 2]", body: "[Short description of the second feature]" },
        { title: "[Feature 3]", body: "[Short description of the third feature]" },
      ],
    },
    gallery: {
      eyebrow: "Gallery",
      title: "[Gallery section title]",
      captions: ["[Image caption 1]", "[Image caption 2]", "[Image caption 3]", "[Image caption 4]"],
    },
    testimonials: {
      eyebrow: "Reviews",
      title: "[Testimonials section title]",
      items: [
        { name: "[Customer name 1]", text: "[First customer's review of the product]" },
        { name: "[Customer name 2]", text: "[Second customer's review]" },
        { name: "[Customer name 3]", text: "[Third customer's review]" },
      ],
    },
    cta: {
      title: "[Final call to order]",
      body: "[Short line pushing the customer to order now via WhatsApp]",
      button: "Order on WhatsApp",
    },
    footer: {
      rights: "All rights reserved",
      brand: "[Brand Name]",
    },
    whatsapp: {
      label: "Order on WhatsApp",
      message: "Hi, I'd like to order [Product Name]",
    },
    langSwitch: "عربي",
  },
} as const;

export type Dictionary = typeof dictionaries.ar;
