import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: "#FAF7F2", // primary background
          soft: "#F5F1EA", // secondary-1
          deep: "#EDE7DC", // secondary-2
        },
        ink: {
          DEFAULT: "#0F1721", // primary text
          soft: "#141119", // secondary-1
          deep: "#241F2E", // secondary-2
        },
        accent: {
          DEFAULT: "#FF7A50", // primary accent
          light: "#FFB199", // secondary light
          dark: "#E85A34", // secondary dark
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        "display-ar": ["var(--font-display-ar)", "serif"],
        "body-ar": ["var(--font-body-ar)", "sans-serif"],
      },
      letterSpacing: {
        tightest: "-0.04em",
      },
      maxWidth: {
        content: "1180px",
      },
      transitionTimingFunction: {
        premium: "cubic-bezier(0.16, 1, 0.3, 1)",
      },
    },
  },
  plugins: [],
};

export default config;
