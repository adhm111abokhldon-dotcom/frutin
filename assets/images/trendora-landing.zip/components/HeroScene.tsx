"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  MeshTransmissionMaterial,
} from "@react-three/drei";

function Bottle({ scrollRef }: { scrollRef: React.MutableRefObject<number> }) {
  const group = useRef<THREE.Group>(null!);

  useFrame((state) => {
    if (!group.current) return;
    const progress = scrollRef.current;
    const idleFloat = Math.sin(state.clock.elapsedTime * 0.6) * 0.06;

    group.current.rotation.y = THREE.MathUtils.lerp(
      group.current.rotation.y,
      progress * Math.PI * 1.6 + state.clock.elapsedTime * 0.04,
      0.05
    );
    group.current.rotation.z = THREE.MathUtils.lerp(
      group.current.rotation.z,
      progress * -0.12,
      0.05
    );
    group.current.position.y = THREE.MathUtils.lerp(
      group.current.position.y,
      idleFloat - progress * 0.5,
      0.05
    );
  });

  return (
    <group ref={group} position={[0, -0.1, 0]}>
      {/* cap */}
      <mesh position={[0, 1.48, 0]} castShadow>
        <cylinderGeometry args={[0.24, 0.24, 0.32, 32]} />
        <meshStandardMaterial color="#0F1721" metalness={0.7} roughness={0.2} />
      </mesh>
      {/* neck */}
      <mesh position={[0, 1.16, 0]} castShadow>
        <cylinderGeometry args={[0.16, 0.2, 0.36, 32]} />
        <meshStandardMaterial color="#241F2E" metalness={0.6} roughness={0.25} />
      </mesh>
      {/* glass body */}
      <mesh position={[0, 0.3, 0]} castShadow>
        <cylinderGeometry args={[0.55, 0.5, 1.5, 48]} />
        <MeshTransmissionMaterial
          color="#FFB199"
          thickness={0.45}
          roughness={0.05}
          transmission={1}
          ior={1.3}
          chromaticAberration={0.02}
          anisotropy={0.15}
          backside
        />
      </mesh>
      {/* liquid inside */}
      <mesh position={[0, 0.12, 0]} scale={[0.82, 0.68, 0.82]}>
        <cylinderGeometry args={[0.5, 0.46, 1.2, 48]} />
        <meshPhysicalMaterial
          color="#E85A34"
          roughness={0.15}
          transmission={0.55}
          thickness={0.5}
        />
      </mesh>
      {/* base ring */}
      <mesh position={[0, -0.46, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.52, 0.06, 48]} />
        <meshStandardMaterial color="#0F1721" metalness={0.5} roughness={0.3} />
      </mesh>
    </group>
  );
}

function Scene({ scrollRef }: { scrollRef: React.MutableRefObject<number> }) {
  return (
    <>
      <ambientLight intensity={0.55} />
      <directionalLight position={[3, 4, 2]} intensity={1.5} color="#FFB199" />
      <directionalLight position={[-4, -1, -2]} intensity={0.5} color="#FF7A50" />
      <Bottle scrollRef={scrollRef} />
      <ContactShadows
        position={[0, -0.75, 0]}
        opacity={0.32}
        scale={6}
        blur={2.6}
        far={2}
        color="#241F2E"
      />
      <Environment preset="studio" />
    </>
  );
}

export default function HeroScene() {
  const scrollRef = useRef(0);
  const heroHeightRef = useRef(1);

  useEffect(() => {
    const hero = document.getElementById("hero");
    heroHeightRef.current = hero ? hero.offsetHeight : window.innerHeight;

    const handleScroll = () => {
      const ratio = window.scrollY / heroHeightRef.current;
      scrollRef.current = Math.min(Math.max(ratio, 0), 1);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  return (
    <Canvas
      camera={{ position: [0, 0.2, 4.4], fov: 36 }}
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true }}
    >
      <Scene scrollRef={scrollRef} />
    </Canvas>
  );
}
