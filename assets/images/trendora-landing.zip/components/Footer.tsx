"use client";

import { useLanguage } from "./LanguageProvider";
import { siteConfig } from "@/lib/config";

export function Footer() {
  const { dict } = useLanguage();
  const year = new Date().getFullYear();

  return (
    <footer className="bg-ink py-10 text-bg/50">
      <div className="container-content flex flex-col items-center justify-between gap-4 text-sm sm:flex-row">
        <span>{siteConfig.brandName}</span>
        <span>
          © {year} {dict.footer.brand} — {dict.footer.rights}
        </span>
      </div>
    </footer>
  );
}
