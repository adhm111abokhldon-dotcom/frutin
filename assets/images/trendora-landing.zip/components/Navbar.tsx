"use client";

import { motion } from "motion/react";
import { useLanguage } from "./LanguageProvider";
import { siteConfig } from "@/lib/config";

export function Navbar() {
  const { dict, toggleLang } = useLanguage();

  const links = [
    { href: "#story", label: dict.nav.story },
    { href: "#notes", label: dict.nav.notes },
    { href: "#gallery", label: dict.nav.gallery },
    { href: "#reviews", label: dict.nav.reviews },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-x-0 top-0 z-40 border-b border-ink/5 bg-bg/80 backdrop-blur-md"
    >
      <nav className="container-content flex h-20 items-center justify-between">
        <span className="text-lg font-semibold tracking-tight text-ink">
          {siteConfig.brandName}
        </span>

        <ul className="hidden items-center gap-9 text-sm text-ink/70 md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="transition-colors duration-300 hover:text-ink"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-4">
          <button
            onClick={toggleLang}
            className="text-sm font-medium text-ink/60 transition-colors duration-300 hover:text-accent-dark"
            aria-label="Toggle language"
          >
            {dict.langSwitch}
          </button>
          <a
            href="#cta"
            className="hidden rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-bg transition-colors duration-300 hover:bg-accent-dark sm:inline-block"
          >
            {dict.nav.cta}
          </a>
        </div>
      </nav>
    </motion.header>
  );
}
