"use client";

import dynamic from "next/dynamic";
import { motion } from "motion/react";
import { useLanguage } from "./LanguageProvider";
import { siteConfig } from "@/lib/config";

const HeroScene = dynamic(() => import("./HeroScene"), {
  ssr: false,
  loading: () => <div className="h-full w-full" />,
});

const ease = [0.16, 1, 0.3, 1] as const;

export function HeroSection() {
  const { dict } = useLanguage();

  return (
    <section
      id="hero"
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-bg pt-20"
    >
      <div className="container-content grid items-center gap-10 md:grid-cols-2 md:gap-6">
        <motion.div
          initial="hidden"
          animate="show"
          variants={{
            hidden: {},
            show: { transition: { staggerChildren: 0.12, delayChildren: 0.2 } },
          }}
          className="relative z-10 order-2 md:order-1"
        >
          <motion.p
            variants={{ hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0 } }}
            transition={{ duration: 0.6, ease }}
            className="mb-4 text-sm text-accent-dark"
          >
            {dict.hero.eyebrow}
          </motion.p>

          <motion.h1
            variants={{ hidden: { opacity: 0, y: 22 }, show: { opacity: 1, y: 0 } }}
            transition={{ duration: 0.7, ease }}
            className="font-display text-[13vw] leading-[0.98] tracking-tightest text-ink sm:text-6xl md:text-7xl"
          >
            {dict.hero.headline}
          </motion.h1>

          <motion.p
            variants={{ hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } }}
            transition={{ duration: 0.6, ease }}
            className="mt-6 max-w-md text-lg leading-relaxed text-ink/65"
          >
            {dict.hero.subheadline}
          </motion.p>

          <motion.div
            variants={{ hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0 } }}
            transition={{ duration: 0.6, ease }}
            className="mt-10 flex flex-wrap items-center gap-5"
          >
            <a
              href={`https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
                dict.whatsapp.message
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full bg-accent px-7 py-3.5 text-sm font-medium text-bg shadow-[0_10px_30px_rgba(255,122,80,0.35)] transition-transform duration-300 hover:scale-[1.03] hover:bg-accent-dark"
            >
              {dict.hero.ctaPrimary}
            </a>
            <a
              href="#notes"
              className="text-sm font-medium text-ink/70 underline decoration-ink/20 underline-offset-4 transition-colors duration-300 hover:text-ink"
            >
              {dict.hero.ctaSecondary}
            </a>
          </motion.div>

          <motion.div
            variants={{ hidden: { opacity: 0 }, show: { opacity: 1 } }}
            transition={{ duration: 0.6, ease }}
            className="mt-14 flex items-baseline gap-2 text-ink/50"
          >
            <span className="text-xs uppercase tracking-wide">
              {dict.hero.priceLabel}
            </span>
            <span className="text-lg font-medium text-ink">{dict.hero.price}</span>
          </motion.div>
        </motion.div>

        <div className="relative order-1 h-[46vh] md:order-2 md:h-[70vh]">
          <HeroScene />
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.6 }}
        className="pointer-events-none absolute inset-x-0 bottom-8 flex justify-center text-xs uppercase tracking-wide text-ink/40"
      >
        {dict.hero.scrollHint}
      </motion.div>
    </section>
  );
}
