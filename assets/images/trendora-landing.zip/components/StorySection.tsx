"use client";

import { motion } from "motion/react";
import { useLanguage } from "./LanguageProvider";

export function StorySection() {
  const { dict } = useLanguage();

  return (
    <section id="story" className="bg-bg-soft py-28 md:py-36">
      <div className="container-content grid gap-14 md:grid-cols-[0.9fr_1.1fr] md:gap-20">
        <div>
          <p className="mb-4 text-sm text-accent-dark">{dict.story.eyebrow}</p>
          <h2 className="font-display text-4xl leading-[1.05] text-ink md:text-5xl">
            {dict.story.title}
          </h2>
        </div>

        <div className="flex flex-col gap-10">
          <p className="max-w-xl text-lg leading-relaxed text-ink/70">
            {dict.story.body}
          </p>

          <motion.blockquote
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="border-s-2 border-accent ps-6 font-display text-2xl italic leading-snug text-ink md:text-3xl"
          >
            {dict.story.quote}
          </motion.blockquote>
        </div>
      </div>
    </section>
  );
}
