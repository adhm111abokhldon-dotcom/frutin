"use client";

import { useLanguage } from "./LanguageProvider";

function PlaceholderTile({
  caption,
  className = "",
}: {
  caption: string;
  className?: string;
}) {
  return (
    <figure
      className={`group relative flex min-h-[220px] flex-col justify-end overflow-hidden rounded-2xl border border-dashed border-ink/15 bg-bg-deep p-5 transition-transform duration-500 ease-premium hover:scale-[1.015] ${className}`}
    >
      <div className="absolute inset-0 flex items-center justify-center text-xs uppercase tracking-wide text-ink/30">
        Product Image
      </div>
      <figcaption className="relative z-10 text-sm text-ink/60">
        {caption}
      </figcaption>
    </figure>
  );
}

export function GallerySection() {
  const { dict } = useLanguage();
  const [c1, c2, c3, c4] = dict.gallery.captions;

  return (
    <section id="gallery" className="bg-bg-soft py-28 md:py-36">
      <div className="container-content">
        <div className="mb-16 max-w-lg">
          <p className="mb-4 text-sm text-accent-dark">{dict.gallery.eyebrow}</p>
          <h2 className="font-display text-4xl leading-[1.05] text-ink md:text-5xl">
            {dict.gallery.title}
          </h2>
        </div>

        <div className="grid gap-5 md:grid-cols-3 md:grid-rows-2">
          <PlaceholderTile caption={c1} className="md:col-span-2 md:row-span-2 md:min-h-[480px]" />
          <PlaceholderTile caption={c2} />
          <PlaceholderTile caption={c3} />
          <PlaceholderTile caption={c4} className="md:col-span-2" />
        </div>
      </div>
    </section>
  );
}
