import type { Metadata } from "next";
import { Fraunces, Manrope, Markazi_Text, IBM_Plex_Sans_Arabic } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/components/LanguageProvider";
import { WhatsAppButton } from "@/components/WhatsAppButton";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600", "700"],
});

const markaziText = Markazi_Text({
  subsets: ["arabic"],
  variable: "--font-display-ar",
  weight: ["500", "600", "700"],
});

const plexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  variable: "--font-body-ar",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "[Brand Name] — [Product Name]",
  description: "[Short product description for search engines]",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body
        className={`${fraunces.variable} ${manrope.variable} ${markaziText.variable} ${plexArabic.variable} bg-bg font-body-ar text-ink antialiased`}
      >
        <LanguageProvider>
          {children}
          <WhatsAppButton />
        </LanguageProvider>
      </body>
    </html>
  );
}
