# Trendora — Product Landing Page

لاندنج بيج لمنتج واحد، هدفها تحول الزوار لطلبات عبر واتساب.

## الستاك

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS — الألوان مأخوذة من نظام Trendora اللوني
- Motion (`motion/react`) للحركة
- Three.js عبر `@react-three/fiber` و `@react-three/drei` — قنينة 3D بالهيرو بتتفاعل مع السكرول

## التشغيل محليًا

```bash
npm install
npm run dev
```

افتح http://localhost:3000

## وين تحط التفاصيل الحقيقية

1. **رقم الواتساب واسم البراند** → `lib/config.ts`
   - `whatsappNumber`: رقم دولي كامل بدون + وبدون مسافات (مثال: `971501234567`)
   - `brandName`, `instagram`

2. **كل نصوص الموقع (عربي/انجليزي)** → `lib/i18n/dictionaries.ts`
   - كل النصوص القابلة للتعديل موسومة بـ `[...]` — استبدلها بالمحتوى الحقيقي (اسم المنتج، السعر، القصة، المزايا، آراء الزبائن...)

3. **الصور** → قسم المعرض حاليًا فيه أماكن فاضية (placeholder tiles) داخل `components/GallerySection.tsx`
   - حط صورك جوا `public/` واستبدل كل `<div>` الخاص بـ placeholder بـ `<Image src="/your-image.jpg" ... />` من `next/image`

4. **الخط والألوان** موجودين بـ `tailwind.config.ts` و `app/layout.tsx` إذا حبيت تبدلهم لاحقًا

## ملاحظات

- الموقع ثنائي اللغة (عربي RTL + انجليزي)، في زر تبديل اللغة بالنافبار
- زر الواتساب العائم ثابت بكل الصفحة وبيفتح محادثة فيها رسالة جاهزة معبّاة مسبقًا
- القنينة 3D بالهيرو بتلف وبتنزل شوي مع السكرول — تقدر تعدل قوة التأثير من `components/HeroScene.tsx`
